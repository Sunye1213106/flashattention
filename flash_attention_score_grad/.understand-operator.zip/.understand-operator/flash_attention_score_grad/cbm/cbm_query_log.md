# CBM Index Log

Layout prepared. Waiting for MCP `index_repository` from /uo-init.
